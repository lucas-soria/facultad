#!/bin/bash

echo "Ingrese el nombre de un archivo comprimido"
read x
pwd
if [[ ! -e $x ]]; then
    tar -cvf $x.tar E2.sh
else
    p="$PWD"
    find $p/$x -delete
fi