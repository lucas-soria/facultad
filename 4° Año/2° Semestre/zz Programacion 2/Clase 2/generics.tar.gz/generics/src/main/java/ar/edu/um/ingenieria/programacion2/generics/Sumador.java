/**
 * 
 */
package ar.edu.um.ingenieria.programacion2.generics;

/**
 * @author daniel
 *
 */
public interface Sumador {

	public void sumar1();

}
