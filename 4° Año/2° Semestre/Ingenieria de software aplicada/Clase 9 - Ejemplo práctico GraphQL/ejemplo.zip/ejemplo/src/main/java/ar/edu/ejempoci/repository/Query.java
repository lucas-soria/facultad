package ar.edu.ejempoci.repository;

    import ar.edu.ejempoci.domain.Region;
    import com.coxautodev.graphql.tools.GraphQLQueryResolver;

public class Query implements GraphQLQueryResolver {
    private RegionRepository regionRepository;
    // private AuthorRepository authorRepository;

    public Query(RegionRepository regionRepository) {
        this.regionRepository = regionRepository;
        //this.bookRepository = bookRepository;
    }

    public Iterable<Region> findAllRegions() {
        return regionRepository.findAll();
    }

    public long countRegions() {
        return regionRepository.count();
    }

}
