export const enum Language {
  FRENCH = 'FRENCH',

  ENGLISH = 'ENGLISH',

  SPANISH = 'SPANISH',
}
