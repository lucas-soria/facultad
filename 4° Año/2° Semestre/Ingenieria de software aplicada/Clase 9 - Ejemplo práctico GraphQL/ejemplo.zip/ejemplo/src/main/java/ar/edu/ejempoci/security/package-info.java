/**
 * Spring Security configuration.
 */
package ar.edu.ejempoci.security;
