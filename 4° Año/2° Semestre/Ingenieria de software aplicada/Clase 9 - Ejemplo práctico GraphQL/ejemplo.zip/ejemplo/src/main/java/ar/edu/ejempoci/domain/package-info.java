/**
 * JPA domain objects.
 */
package ar.edu.ejempoci.domain;
