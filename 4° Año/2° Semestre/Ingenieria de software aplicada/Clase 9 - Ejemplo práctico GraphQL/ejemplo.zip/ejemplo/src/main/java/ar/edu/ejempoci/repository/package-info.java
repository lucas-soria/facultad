/**
 * Spring Data JPA repositories.
 */
package ar.edu.ejempoci.repository;
