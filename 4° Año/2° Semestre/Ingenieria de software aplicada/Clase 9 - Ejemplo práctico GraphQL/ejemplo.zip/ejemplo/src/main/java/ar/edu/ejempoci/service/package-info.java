/**
 * Service layer beans.
 */
package ar.edu.ejempoci.service;
