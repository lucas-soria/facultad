import 'zone.js/dist/zone';
import '@angular/localize/init';
require('../manifest.webapp');
