#include <stdio.h>
#include <stdlib.h>

int main ()
{
     int nro1, nro2, suma=0, resta=0;
     printf("Ingrese los dos valores enteros\n");
     scanf("%d %d", &nro1, &nro2);
     if (nro1 > nro2)
             {
             resta = nro1 - nro2;
              printf("la resta es =  %d \n",resta);
              }
    
      
     system("pause");
     return 0;
}
        
