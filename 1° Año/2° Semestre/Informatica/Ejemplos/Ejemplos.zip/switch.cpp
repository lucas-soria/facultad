# include <stdlib.h>
# include <stdio.h>
int main ()
{
    int opcion;
    printf("Ingrese un numero entero ");
    scanf("%d", &opcion);
    
switch (opcion)
{
    case 1: printf("Su opcion es 1\n");
          break;
    case 2:printf("Su opcion es 2\n");
          break;
    case 3: printf("Su opcion es 3\n");
          break;
    default: printf( "Elija una opcion entre 1 y 3\n");

}
system("pause");
return 0;
}
