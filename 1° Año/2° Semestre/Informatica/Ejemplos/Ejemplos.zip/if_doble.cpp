# include <stdio.h>
# include <stdlib.h>
# include <math.h>
int main ()
{
 int nro, suma, resta, par,valor;
 printf("ingrese un valor ");
 scanf("%d", &nro);
 if (nro < 0)
  {
  valor = abs(nro);
  printf ("el valor absoluto es %d\n", valor);
    }
    else 
    {
    valor = nro;
    printf ("valor %d\n", valor);
}
  system ("pause");
  return 0;
}
