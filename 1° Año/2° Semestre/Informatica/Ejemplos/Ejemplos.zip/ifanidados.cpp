//calcula el mayor de tres numeros enteros

# include <stdio.h>
# include <stdlib.h>

int main ()
{
     int nro1, nro2, nro3;
     printf("Ingrese los tres valores enteros\n");
     scanf("%d %d %d", &nro1, &nro2, &nro3);
     if (nro1 > nro2)
     {
        if (nro1 > nro3)
           printf ("el mayor es nro1: %d \n", nro1);
           }
        else if (nro2 > nro1) 
            {
               if (nro2 > nro3)
                  printf("el mayor es nro2: %d\n", nro2);
                  else printf("el mayor es nro3 %d\n", nro3);
                  }
        system ("pause");
        return 0;
     
}
