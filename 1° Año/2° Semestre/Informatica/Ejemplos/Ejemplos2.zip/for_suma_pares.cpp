//suma los primeros 10 numeros pares


#include <stdio.h> 
#include <stdlib.h>

int main() 
{
	int n, suma = 0; 
	for  (n  =  1;  n <=  10;  n++) 
     {
     	suma +=  2*n; 
     	printf (" la suma parcial es %d\n", suma);
     }
	printf("La  suma de los 10 primeros numeros pares: %d\n",suma); 
	system ("pause");
} 
