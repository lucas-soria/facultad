# include <stdio.h>
# include <stdlib.h>
int main()
{
    int cuenta, valor_inicial, valor_parada;
    printf("Ingrese el valor inicial\n");
    scanf ("%d",&valor_inicial);
    printf("Ingrese el valor de parada\n");
    scanf ("%d",&valor_parada);
    cuenta =  valor_inicial; 
    for (cuenta  =  valor_inicial; cuenta <  valor_parada; cuenta++) 
    {
           printf ("Pasada nro %d\t ", cuenta); 
    }  /*  fin de for  */ 
    system("pause");
}
