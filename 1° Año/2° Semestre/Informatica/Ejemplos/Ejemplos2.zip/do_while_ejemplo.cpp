//Imprimir diez veces la serie de n�meros del 1 al 10 usando el bucle do�while:

#include <stdio.h>
#include <stdlib.h>
main(void)
{
   int i=1;
   int j=1;
   do
   {
       do{
           printf("%i ", j);
           j = j+1;
       }while (j<=10);
       j=1;
       printf("\n");
       i = i+1;
    }while (i<=10);
    printf("\n");
    system("PAUSE");
 }
