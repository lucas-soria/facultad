# include <stdio.h>
# include <stdlib.h>

int main()
{
    int cuenta, valor_inicial, valor_parada;
    printf("Ingrese el valor inicial\n");
    scanf ("%d",&valor_inicial);
    printf("Ingrese el valor de parada\n");
    scanf ("%d",&valor_parada);
    cuenta =  valor_inicial; 
    while  (cuenta  <  valor_parada)
    {
           printf ("Pasada nro %d\t ", cuenta); 
           cuenta++  ; 
           }  /*  fin de while  */ 
    system("pause");
    return 0;
}
