//Visualizar las potencias de 2 cuyos valores estan en el rango 1 a 1000

# include <stdio.h>
# include <stdlib.h>

int main()
{
int potencia = 1; 
potencia =  1; 
while  (potencia  <  1000) 
       {
       printf  ("%d  \n",potencia)  ; 
       potencia = potencia * 2 ; 
       }  
 system ("pause");
    }
