# include <stdio.h>
# include <stdlib.h>
int main()
{
    int cuenta, valor_inicial, valor_parada;
    printf("Ingrese el valor inicial\n");
    scanf ("%d",&valor_inicial);
    printf("Ingrese el valor de parada\n");
    scanf ("%d",&valor_parada);
    cuenta =  valor_inicial; 
    if (valor_inicial < valor_parada)
    {
    do {
           printf ("Pasada nro %d\t ", cuenta); 
           cuenta++  ; 
           } while (cuenta  <  valor_parada);  /*  fin de do-while  */ 
    }
    system("pause");
}



