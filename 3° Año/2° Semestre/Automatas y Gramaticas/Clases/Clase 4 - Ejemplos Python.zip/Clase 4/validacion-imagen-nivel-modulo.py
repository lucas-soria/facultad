import re
regex = re.compile(r"^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$")
ip = input("Ingrese una extensión de una IP: ")
if regex.match(ip):
	print('La extensión ', ip, 'se corresponde con una IP')
else:
	print('La extensión ', ip, 'no se corresponde con una IP')
