from Logger import Logger


class Clazz3:

    def method1(self):
        Logger().get_logger().add_log("Clazz3:method1")
