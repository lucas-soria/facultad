from Logger import Logger


class Clazz1:

    def method1(self):
        Logger().get_logger().add_log("Clazz1:method1")
