/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package observer;

/**
 *
 * @author Lucas
 */
public class Administracion implements ILibroMalEstado {
    
    public void update(){
        System.out.println("Administacion: \nEnvio una queja formal...");
    }
    
}
