/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package patroncomposite;

/**
 *
 * @author Lucas
 */
public class SectorContaduria extends Composite {
    private int cantidadContadores;
    
    public int getCantidadContadores(){
        return cantidadContadores;
    }
    
    public void setCantidadContadores(int cantidadContadores) {
        this.cantidadContadores = cantidadContadores;
    }
    
}
