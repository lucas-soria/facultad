/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package patroncomposite;

import java.util.ArrayList;

/**
 *
 * @author Lucas
 */
public class Composite implements ISueldo{
    private ArrayList<ISueldo> empleados = new ArrayList<>();
    
    @Override
    public double getSueldo() {
        double sumador = 0;
        for (int i = 0; i < empleados.size(); i++) {
            sumador = sumador + empleados.get(i).getSueldo();
        }
        return sumador;
    }
    
    public void agrega(ISueldo p) {
        empleados.add(p);
    }
}
