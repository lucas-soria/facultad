/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package patroncomposite;

/**
 *
 * @author Lucas
 */
public class PatronComposite {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Composite banco  = new Composite();
        SectorAdministrativo administracion = new SectorAdministrativo();
        SectorCajas cajas = new SectorCajas();
        SectorContaduria contaduria = new SectorContaduria();
        SectorGerencia gerencia = new SectorGerencia();
        SectorRRHH rrhh = new SectorRRHH();
        
        banco.agrega(gerencia);
        banco.agrega(contaduria);
        banco.agrega(administracion);
        administracion.agrega(cajas);
        administracion.agrega(rrhh);
        
        Empleado cajero1 = new Empleado("Lucas Soria", "Cajero", 2000);
        Empleado cajero2 = new Empleado("Valentina Scalco", "Cajero", 2000);
        cajas.agrega(cajero1);
        cajas.agrega(cajero2);
        
        Empleado gerente = new Empleado("Franco Santander", "Gerente", 5000);
        gerencia.agrega(gerente);
        
        Empleado selectora = new Empleado("Agustina Capo", "Selectora", 1500);
        rrhh.agrega(selectora);
        
        Empleado contador = new Empleado("Philipp von Kesselsttatt", "Contador", 3000);
        contaduria.agrega(contador);
        
        System.out.println("El total de sueldos a pagar es: " + banco.getSueldo());
    }
    
}
