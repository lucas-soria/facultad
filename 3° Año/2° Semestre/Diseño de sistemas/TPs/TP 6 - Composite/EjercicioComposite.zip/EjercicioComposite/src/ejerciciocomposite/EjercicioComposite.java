/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciocomposite;

/**
 *
 * @author Lucas
 */
public class EjercicioComposite {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ExpressionCompositeSum sum1 = new ExpressionCompositeSum();
        ExpressionCompositeSum sum2 = new ExpressionCompositeSum();
        ExpressionCompositeSum sum3 = new ExpressionCompositeSum();
        ExpressionCompositeRes res1 = new ExpressionCompositeRes();
        ExpressionCompositeRes res2 = new ExpressionCompositeRes();
        ExpressionCompositeMul mul = new ExpressionCompositeMul();
        ExpressionCompositeDiv div = new ExpressionCompositeDiv();
        ExpressionLeaf uno = new ExpressionLeaf(1);
        ExpressionLeaf dos = new ExpressionLeaf(2);
        ExpressionLeaf tres = new ExpressionLeaf(3);
        ExpressionLeaf cuatro = new ExpressionLeaf(4);
        
        // ((((1+2)+(4-3))+(2*3))-(2/4))
        sum1.add(uno);
        sum1.add(dos);
        res1.add(cuatro);
        res1.add(tres);
        sum2.add(sum1);
        sum2.add(res1);
        mul.add(dos);
        mul.add(tres);
        sum3.add(sum2);
        sum3.add(mul);
        div.add(dos);
        div.add(cuatro);
        res2.add(sum3);
        res2.add(div);
        
        double cuenta = res2.operation();
        System.out.println("La expresion da como resultado: " + cuenta);
    }
}
