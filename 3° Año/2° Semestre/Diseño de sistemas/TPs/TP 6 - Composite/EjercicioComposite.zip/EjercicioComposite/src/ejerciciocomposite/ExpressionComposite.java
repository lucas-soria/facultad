/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciocomposite;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lucas
 */
abstract class ExpressionComposite implements Expression{
    protected List<Expression> expressionList;

    public ExpressionComposite(){
        this.expressionList = new ArrayList<>();
    }

    @Override
    public void add(Expression expression){
        this.expressionList.add(expression);
    }
    
    @Override
    public void remove(Expression expression){
        this.expressionList.remove(expression);
    }

    @Override
    public double operation(){
        throw new UnsupportedOperationException("Unsupported operation");
    }
}
