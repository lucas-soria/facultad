/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciocomposite;

/**
 *
 * @author Lucas
 */
public class ExpressionLeaf implements Expression {
    private int number;

    public ExpressionLeaf(int number){
        this.number = number;
    }
    
    @Override
    public void add(Expression expression){
        // No agrega nada porque es una hoja
    }
    
    @Override
    public void remove(Expression expression){
        // No agrega nada porque es una hoja
    }
    
    @Override
    public double operation(){
    	return this.number;
    }
}
