/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciocomposite;


/**
 *
 * @author Lucas
 */
public class ExpressionCompositeRes extends ExpressionComposite{
    @Override
    public double operation(){
        double numeros[] = expressionList.stream().mapToDouble(Expression::operation).toArray(), result = numeros[0];
        int len = numeros.length;
        for (int i = 1; i < len; i++) {
            result = result - numeros[i];
        }
        return result;
    }
}
