/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciocomposite;

/**
 *
 * @author Lucas
 */
public interface Expression {
    
    public void add(Expression expression);
    
    public void remove(Expression expression);
    
    public double operation();
    
}
