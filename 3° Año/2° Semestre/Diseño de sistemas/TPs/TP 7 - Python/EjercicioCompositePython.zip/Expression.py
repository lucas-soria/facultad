class Expression():

    def add(self, expression):
        pass

    def remove(self, expression):
        pass

    def operation(self):
        pass
