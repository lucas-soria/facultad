from Composite import Composite


class SectorRRHH(Composite):

    def get_cantidadSelectores(self):
        return self.cantidadSelectores

    def set_cantidadSelectores(self, cantidadSelectores):
        self.cantidadSelectores = cantidadSelectores
