class ISueldo:

    def getSueldo(self):
        pass
