class Persona:
	def __init__(self, nombre, apellido, edad):
		self.__nombre = nombre
		self.__apellido = apellido
		self.__edad = edad
	
	def saltar(self):
		return 0
	
	def estudiar(self):
		pass
	
	@property
	def nombre(self):
		return self.__nombre
	
	@property
	def apellido(self):
		return self.__apellido
	
	@property
	def edad(self):
		return self.__edad
	
	@nombre.setter
	def nombre(self, nombre):
		self.__nombre = nombre
	
	@apellido.setter
	def apellido(self, apellido):
		self.__apellido = apellido
	
	@edad.setter
	def edad(self, edad):
		self.__edad = edad
	