class Direccion:
	def __init__(self, calle, numero):
		self.__calle = calle
		self.__numero = numero
	
	
	@property
	def calle(self):
		return self.__calle
	
	@property
	def numero(self):
		return self.__numero
	
	@calle.setter
	def calle(self, calle):
		self.__calle = calle
	
	@numero.setter
	def numero(self, numero):
		self.__numero = numero
	