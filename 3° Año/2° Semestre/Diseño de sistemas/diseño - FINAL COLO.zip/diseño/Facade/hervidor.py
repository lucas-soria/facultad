class Hervidor(object):
    def hervirVegetales(self):
        print("Todos los vegetales se hirvieron")
