from cocinar import Cocinar


if __name__ == '__main__':
    cocinar = Cocinar()
    cocinar.preparaComida()
