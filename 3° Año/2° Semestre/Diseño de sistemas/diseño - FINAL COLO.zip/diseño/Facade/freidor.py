class Freidor(object):
    def freir(self):
        print("Todos los vegetales fueron mezclado y fritos")
