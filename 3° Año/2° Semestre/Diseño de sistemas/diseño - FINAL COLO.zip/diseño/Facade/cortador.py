class Cortador(object):
    def cortarVegetales(self):
        print("Todos los vegetales fueron cortados")
