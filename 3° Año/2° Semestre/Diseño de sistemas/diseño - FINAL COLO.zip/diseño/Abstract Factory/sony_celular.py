from celular import Celular


class SonyCelular(Celular):
    def funcion_celular(self):
        return "Funcion Celular Sony Xperia"
