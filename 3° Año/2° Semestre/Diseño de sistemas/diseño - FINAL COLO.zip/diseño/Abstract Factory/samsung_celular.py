from celular import Celular


class SamsungCelular(Celular):
    def funcion_celular(self):
        return "Funcion Celular Samsung Galaxy"
