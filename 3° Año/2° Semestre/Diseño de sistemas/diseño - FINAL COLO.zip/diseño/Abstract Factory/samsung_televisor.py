from televisor import Televisor


class SamsungTelevisor(Televisor):
    def funcion_televisor(self):
        return "Funcion Televisor Samsung"
