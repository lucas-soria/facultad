from abc import ABC, abstractmethod


class Celular(ABC):
    @abstractmethod
    def funcion_celular(self):
        pass
