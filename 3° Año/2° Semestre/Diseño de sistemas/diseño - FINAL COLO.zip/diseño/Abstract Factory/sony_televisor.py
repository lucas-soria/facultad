from televisor import Televisor


class SonyTelevisor(Televisor):
    def funcion_televisor(self):
        return "Funcion Televisor sony Bravia"
