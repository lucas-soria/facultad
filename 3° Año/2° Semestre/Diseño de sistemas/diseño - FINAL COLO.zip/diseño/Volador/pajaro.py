from volador import Volador


class Pajaro(Volador):
    def volar(self):
        print("El pajaro esta volando")

    def aterrizar(self):
        print("Aterriza el pajaro en un arbol")
