from volador import Volador


class Superman(Volador):
    def volar(self):
        print("Superman esta volando")

    def aterrizar(self):
        print("Superman aterrizo en un edificio")
