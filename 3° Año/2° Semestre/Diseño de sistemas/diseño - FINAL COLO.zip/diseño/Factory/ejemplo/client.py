class Cliente:
    def codigo_cliente(self, chair):
        chair = chair.create_chair()
        print(chair.get_dimenisons())
