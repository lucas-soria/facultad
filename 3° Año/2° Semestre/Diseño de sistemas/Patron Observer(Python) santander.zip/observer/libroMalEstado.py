class libroMalEstado():
    def update(self,libro):
        pass

