class Subject():

    @classmethod
    def attach(cls,observer):
        pass

    @classmethod
    def detach(cls,observer):
        pass

    @classmethod
    def notificar_observers(cls,libro):
        pass

    @classmethod
    def limipar_observers(cls):
        pass


