class Subject:

    def attach(self, observador):
        pass

    def dettach(self, observador):
        pass
    
    def notifyObservers(self):
        pass
