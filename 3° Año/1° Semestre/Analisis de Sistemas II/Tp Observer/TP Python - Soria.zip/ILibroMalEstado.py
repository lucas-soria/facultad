class ILibroMalEstado:

    def update(self):
        pass
