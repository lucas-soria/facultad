class Libro:

    def __init__(self):
        self.titulo = ""
        self.estado = ""
    
    def getTitulo(self):
        return self.titulo
    
    def setTitulo(self, titulo):
        self.titulo = titulo
    
    def getEstado(self):
        return self.estado
    
    def setEstado(self, estado):
        self.estado = estado
