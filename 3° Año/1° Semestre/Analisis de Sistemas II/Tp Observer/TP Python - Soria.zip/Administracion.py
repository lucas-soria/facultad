from ILibroMalEstado import ILibroMalEstado


class Administracion(ILibroMalEstado):

    def update(self):
        print("\nAdministracion:\n\tEnvio una queja formal...")
